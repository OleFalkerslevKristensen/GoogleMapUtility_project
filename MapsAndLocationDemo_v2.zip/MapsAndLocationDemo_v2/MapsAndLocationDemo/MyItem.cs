using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
//using Com.Google.Maps.Android;
using Android.Gms.Maps.Model;

namespace MapsAndLocationDemo
{
    /*
    public class MyItem : ClusterItem
    {
        private readonly LatLng mPosition;

        public MyItem(double lat, double lng)
        {
            mPosition = new LatLng(lat, lng);
        }

        public override LatLng Position
        {
            get
            {
                return mPosition;
            }
        }
    }
     * 
     * */
}